<html>

<head>
    <title>BOOK</title>
    <style>
    body {
        margin: 0;
        font-family: 'Times New Roman', Times, serif;
        background-image: url("16.webp");
        background-size: cover;
    }

    .topnav {
        overflow: hidden;
        background-color: silver;
        height: 70px;
        border: 3px silver;
    }

    .topnav a {
        float: left;
        color: #f2f2f2;
        text-align: center;
        padding: 14px 16px;
        font-size: 35px;
        font-weight: bold;

    }
    </style>

<body>
    <div class="topnav">
        <a class="active" href="home.html"><img src="909.jpg" height="55" width="60"></a>
        <a href="book.php">BOOKS</a>
    </div>
    <?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "books";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "  CONNECTION ESTABLISHED \r\n";
//echo "  INSERTION IN PROCESS";
$book_id=$_POST["t1"];

$Query2="select count(*) from book where book_id='$book_id'";
$Execute = mysqli_query($conn,$Query2);
$count = mysqli_fetch_row($Execute);


if($count[0]==1)
{ 
    
    $sql = "DELETE FROM book WHERE book_id='$book_id'";
    if ($conn->query($sql) == TRUE) {
        echo '<div>
    <h1 style="color:black;font-size:40px; font-family: "Roboto", sans-serif;margin:auto;">Data deleted successfully</h1>
       </div>';
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
else{
    echo '<div>
    <h1 style="color:black;font-size:40px; font-family: "Roboto", sans-serif;margin:auto;"> Data not found</h1>
       </div>';
}
$conn->close();
?>
    <form>
        <button type="submit" style="  height: 50px;width: 150px;cursor:pointer;border-radius:15px;
border: 3px silver;background-color: silver;color:black;font-size:17px;" formaction="book.php">Back</button>
    </form>

    <body>
        <html>