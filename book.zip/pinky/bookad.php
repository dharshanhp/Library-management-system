<?php
 session_start();
 if(isset($_SESSION['user']))
 {

 }
 else{
  echo"<script>location.href='login.html'</script>";
 }
?>
<!doctype html>
<html>

<head>
    <title>BOOK </title>
    <style>
    body {
        margin: 0;
        font-family: 'Times New Roman', Times, serif;
        background-image: url("4.jpeg");
        background-size: cover;
    }

    .topnav {
        overflow: hidden;
        background-color: silver;
        height: 70px;
        border: 3px silver;
    }

    .topnav a {
        float: left;
        color: #f2f2f2;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
        font-size: 35px;
        font-weight: bold;
        text-decoration: none;

    }

    .topnav-right {
        float: right;
    }

    fieldset {
        background: white;
        padding: 10px;
        margin: auto;
        max-width: 593px;
        box-shadow: 1px 1px 25px silver;
        border-radius: 10px;
        border: 6px silver;


    }
    </style>
</head>

<body>
    <div class="topnav">
        <a class="active" href="home.html"><img src="909.jpg" height="55" width="60"></a>
        <a href="book.php">BOOKS</a>
        <div class="topnav-right">
            <a href="logout.php">logout</a>
        </div>
    </div>

    <form>
        <button type="submit" formaction="book.php" style="margin:15px;height: 30px;width: 100px;cursor:pointer;border-radius:15px;
border: 3px silver;background-color:silver;color:black;font-size:17px;">
            Back</button>
    </form>
    <form method="post" action="bookad.php">
        <fieldset>
            <input type="text" name="id" placeholder=" Enter book_id" style="width:100%;height:30px;
   border: 2px silver; border-radius:3px; background:transparent;" required>
            <br><br>
            <input type="text" name="Au" placeholder="Enter the authors name" style="width:100%;height:30px;
   border: 2px silver; border-radius:3px;background:transparent;" required>
            <br><br>

            <input type="text" name="pr" placeholder="Enter the price " style="width:100%;height:30px;
   border: 2px silver; border-radius:3px;background:transparent;" required>
            <br><br>
            <input type="number" step=any name="de" placeholder="Enter the details" style="width:280px;height:30px;
   border: 2px silver; border-radius:3px;background:transparent;" min="1" required>

            <input type="number" step=any name="na" placeholder="Enter the name" style="width:300px;height:30px;
   border: 2px silver; border-radius:3px;background:transparent;" min="15" required>
            <br><br>
            <input type="submit" name="submit" value="save" style="width:100%;height:30px;
   border: 2px silver; border-radius:3px; cursor:pointer;background-color: silver">&ensp;
        </fieldset>
    </form>
</body>

</html>
<?php
if(isset($_POST["submit"]))
{
  // define variables and set to empty values
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "books";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "  CONNECTION ESTABLISHED \r\n";
//echo "  INSERTION IN PROCESS";
$id = $_POST["id"];
  $Au = $_POST["Au"];
  $pr= $_POST["pr"];
  $de = $_POST["de"];
  $na = $_POST["na"];



$sql = "INSERT INTO book( book_id,AUTHORS,price,details,name)
VALUES ('$id','$Au','$pr','de','na')";
if ($conn->multi_query($sql) == TRUE) {
  echo'<div>
      <h1 style="color:black;font-size:20px; font-family: "Roboto", sans-serif;margin:auto;">New record of id='
      .$id. ' inserted successfully</h1>
         </div>';
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}

?>